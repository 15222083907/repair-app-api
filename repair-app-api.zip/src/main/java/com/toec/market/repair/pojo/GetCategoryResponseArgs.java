package com.toec.market.repair.pojo;

import com.toec.market.repair.entity.Category;

public class GetCategoryResponseArgs {

	private Category category;

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
}
