package com.toec.market.repair.pojo;

import java.util.List;

import com.toec.market.repair.entity.Category;

 
public class GetAllCategoryResponseArgs {

	private List<Category> categoryList;

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	
	
	
}
