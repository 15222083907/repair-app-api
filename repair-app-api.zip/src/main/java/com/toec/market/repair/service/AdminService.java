package com.toec.market.repair.service;


import com.toec.market.repair.entity.Admin;
import com.toec.market.repair.entity.AdminExample;

public interface AdminService extends BaseService<Admin,Integer,AdminExample> {

}
